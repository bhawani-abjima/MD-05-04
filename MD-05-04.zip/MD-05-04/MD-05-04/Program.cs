﻿using System;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Channels;
using System.Runtime.Serialization;
using System.Diagnostics.CodeAnalysis;

[Serializable]
public class UserAlreadyLoggedInException:Exception
{
    public UserAlreadyLoggedInException() : base()                    //inner exception handling
    { 
    
    }
    public UserAlreadyLoggedInException(string message) : base(message)
    {

    }
    public UserAlreadyLoggedInException(string message,Exception innerException) : base(message,innerException)
    {

    }
    public UserAlreadyLoggedInException(SerializationInfo info,StreamingContext context
        ) : base(info,context)
    {
    
    }
}
class exceptionhandling
{
    int result;
    exceptionhandling()
    {
        result = 0;
    }
    public void division(int num1, int num2)
    {
        try
        {
            result = num1 / num2;
        }
        catch (DivideByZeroException e)
        {
            Console.WriteLine("Exception caught: {0}", e);
        }
        finally
        {
            Console.WriteLine("Result: {0}", result);
        }
    }
    public static void Main()
    {
        StreamReader STR = null;
        try
        {                                                                         //try ,catch ,finally uses 
            STR = new StreamReader(@"C:\SampleFiles\Sample101.txt");
            Console.WriteLine(STR.ReadToEnd());
            STR.Close();
        }
        catch (FileNotFoundException EZ)
        {
            //Log The Details
            Console.WriteLine("Please Check The File If Exists or Not", EZ.FileName);

        }
        catch(Exception EZ)
        {
            Console.WriteLine(EZ.Message);
        }
        finally
        {
            if (STR != null)
            {
                STR.Close();
            }
        }
        exceptionhandling EXP = new exceptionhandling();
        EXP.division(25, 0);

        int[] arr = { 1, 2, 3, 4, 5 };
        for (int i = 0; i < arr.Length; i++)
        {
            Console.WriteLine(arr[i]);
        }

        try
        {
            Console.WriteLine(arr[7]);
        }
        catch (IndexOutOfRangeException R)
        {
            Console.WriteLine("An Exception has occurred : {0}", R.Message);
        }

        try
        {
            Console.WriteLine("enter the first number");
            int XC = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the first number");
            int XB = Convert.ToInt32(Console.ReadLine());

            int Result = XB / XC;
            Console.WriteLine("RESULT={0}", Result);
        }
        catch (Exception DX)
        {
            string filePath = @"C:\SampleFiles\Sample101.txt";
            StreamWriter HH= new StreamWriter(filePath);
            HH.Write(DX.GetType().Name);
            HH.Close();
            Console.WriteLine("There is a Problem,Please Try later");
        }

        try
        {
            throw new UserAlreadyLoggedInException("user is logged no dupilicate session allowed");    //abuse exception handling

        }
        catch (UserAlreadyLoggedInException PP)
        {
            Console.WriteLine(PP.Message);
        }

        try
        {
            Console.WriteLine("please enter Dumerator");
            int Numerator = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("please enter Dumerator");
            int Denominator = Convert.ToInt32(Console.ReadLine());

            int Result = Numerator / Denominator;
            Console.WriteLine("Result={0}", Result);
        }
        catch (FormatException)
        {
            Console.WriteLine("write a number");

        }
        catch(OverflowException)
        {
            Console.WriteLine("only numbers between {0} && {1} are allowed",Int32.MinValue ,Int32.MaxValue);
        }
    }
}